# Phan_II_Re_Nhanh - Bài 11
# Viết code Python cho bài này tại đây

def main():
    pass

if __name__ == '__main__':
    main()
