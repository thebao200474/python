# Bai_Tap_Tong_Hop - Bài 6
# Viết code Python cho bài này tại đây

def main():
    pass

if __name__ == '__main__':
    main()
