# Phan_I_Cau_Lenh_Don - Bài 7
# Viết code Python cho bài này tại đây

def main():
    pass

if __name__ == '__main__':
    main()
