# Python Basic Exercises
Mỗi bài được tách thành 1 file riêng để dễ upload lên GitHub.
